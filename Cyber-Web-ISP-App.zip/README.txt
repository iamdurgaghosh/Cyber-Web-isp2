Cyber Web ISP — প্রাথমিক মোবাইল-ফ্রেন্ডলি অ্যাপ

ফাইল:
- index.html: মূল অ্যাপ
- manifest.json: PWA/হোম-স্ক্রিন সেটিংস

GitHub Pages-এ আপলোড:
1. ZIP ফাইলটি Android ফোনে Extract করুন।
2. https://github.com/iamdurgaghosh/Cyber-Web-isp2 খুলুন।
3. Add file → Upload files নির্বাচন করুন।
4. index.html এবং manifest.json ফাইল দুটো repository-র root-এ আপলোড করুন।
5. Commit changes চাপুন।
6. প্রকাশিত পেজ খুলুন: https://iamdurgaghosh.github.io/Cyber-Web-isp2/

গুরুত্বপূর্ণ:
- প্যাকেজের মূল্যগুলো নমুনা—আপনার প্রকৃত মূল্য দিয়ে বদলাতে হবে।
- ফোন/WhatsApp নম্বর ও support@example.com নমুনা—নিজের তথ্য বসাতে হবে।
- অভিযোগ ফর্ম শুধু বার্তার খসড়া তৈরি করে; সার্ভারে জমা দেয় না।
- নিরাপদ Login, বিল দেখা, পেমেন্ট এবং Admin Panel-এর জন্য আলাদা backend/database ও নিরাপদ integration দরকার।
- Android-এ Chrome দিয়ে সাইট খুলে মেনু থেকে “Add to Home screen” থাকলে সেটি ব্যবহার করে হোম স্ক্রিনে শর্টকাট যোগ করা যায়। এটি নিজে থেকে APK নয়।
